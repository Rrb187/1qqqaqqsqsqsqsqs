import Header from '../Header';

export default function HeaderExample() {
  return (
    <div className="relative min-h-[100px] bg-gradient-to-br from-purple-900/50 to-blue-900/50">
      <Header />
    </div>
  );
}
